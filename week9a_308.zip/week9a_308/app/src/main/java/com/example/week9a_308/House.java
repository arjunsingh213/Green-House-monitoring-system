package com.example.week9a_308;

public class House {
    public String PlithArea;
    public String BedRooms;
    public String BathRooms;
}