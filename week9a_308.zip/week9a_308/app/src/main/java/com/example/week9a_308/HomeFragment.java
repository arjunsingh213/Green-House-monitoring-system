package com.example.week9a_308;

import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
public class HomeFragment extends Fragment implements View.OnClickListener {
    Context context;
    House house;
    TextView textPrice;
    EditText textPlinthArea, textBedRooms,textBathRooms;
    public HomeFragment() {}
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        return fragment;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getActivity().setTitle("House Price Prediction");
        house = new House();
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        this.context = container.getContext();
        textPlinthArea = view.findViewById(R.id.textPlinthArea);
        textBedRooms = view.findViewById(R.id.textBedRooms);
        textBathRooms = view.findViewById(R.id.textBathRooms);
        textPrice = view.findViewById(R.id.textPrice);
        Button btnPredictPrice = view.findViewById(R.id.btnPredictPrice);
        btnPredictPrice.setOnClickListener(this);
        return view;
    }
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnPredictPrice:
                house.PlithArea = textPlinthArea.getText().toString();
                house.BedRooms = textBedRooms.getText().toString();
                house.BathRooms = textBathRooms.getText().toString();
                GetPrice();
                break;
        }
    }
    private void GetPrice() {
        String url = "http://13.233.145.243/mru359/predictPrice?";
        url += "bedRooms=" + house.BedRooms + "&";
        url += "bathRooms=" + house.BathRooms + "&";
        url += "area=" + house.PlithArea;
        // creating a new variable for our request queue
        RequestQueue queue = Volley.newRequestQueue(context);
        // make json array request and then extracting data from each json object.
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new
                Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            JSONObject responseObj = response.getJSONObject(0);
                            String returnValue = responseObj.getString("Price");
                            textPrice.setText("Price: $" + returnValue);
                            Toast.makeText(context, returnValue, Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "Fail to get the data..", Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(jsonArrayRequest);
    }
}