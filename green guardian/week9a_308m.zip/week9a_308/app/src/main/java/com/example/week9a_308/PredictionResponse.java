package com.example.week9a_308;


import com.google.gson.annotations.SerializedName;

public class PredictionResponse {

    @SerializedName("predicted_class")
    private String predictedClass;

    public String getPredictedClass() {
        return predictedClass;
    }

    public void setPredictedClass(String predictedClass) {
        this.predictedClass = predictedClass;
    }
}
