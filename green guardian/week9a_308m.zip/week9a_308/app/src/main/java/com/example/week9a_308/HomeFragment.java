package com.example.week9a_308;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.core.app.ActivityCompat;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class HomeFragment extends Fragment {

    private static final String TAG = "BluetoothArduino";
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); // Standard SerialPortService ID

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private BluetoothDevice bluetoothDevice;

    private TextView humidityTextView;
    private TextView temperatureCelsiusTextView;
    private TextView temperatureFahrenheitTextView;
    private TextView moistureLevelTextView;
    private TextView fanStatusTextView;
    private TextView pumpStatusTextView;

    private Button fanButton;
    private Button pumpButton;

    private OutputStream outputStream;
    private Switch manualSwitch;

    private boolean isFanOn = false;
    private boolean isPumpOn = false;

    public HomeFragment() {
        // Required empty public constructor
    }

    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(getActivity(), "Bluetooth is not supported on this device", Toast.LENGTH_SHORT).show();
            getActivity().finish();
        }

        if (!bluetoothAdapter.isEnabled()) {
            Toast.makeText(getActivity(), "Please enable Bluetooth", Toast.LENGTH_SHORT).show();
            getActivity().finish();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        initializeViews(view);
        connectBluetooth();
        return view;
    }

    private void initializeViews(View view) {

        humidityTextView = view.findViewById(R.id.humidityTextView);
        temperatureCelsiusTextView = view.findViewById(R.id.temperatureCelsiusTextView);
        temperatureFahrenheitTextView = view.findViewById(R.id.temperatureFahrenheitTextView);
        moistureLevelTextView = view.findViewById(R.id.moistureLevelTextView);
        fanStatusTextView = view.findViewById(R.id.fanStatusTextView);
        pumpStatusTextView = view.findViewById(R.id.pumpStatusTextView);

        fanButton = view.findViewById(R.id.fanButton);
        pumpButton = view.findViewById(R.id.pumpButton);

        manualSwitch = view.findViewById(R.id.switch1);

        fanButton.setOnClickListener(v -> toggleFan());
        pumpButton.setOnClickListener(v -> togglePump());

        manualSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    // Send command to turn on manual mode
                    sendCommand("MANUAL_ON");
                } else {
                    // Send command to turn off manual mode
                    sendCommand("MANUAL_OFF");
                }
            }
        });
    }

    private void connectBluetooth() {
        String deviceAddress = "00:23:09:01:65:50"; // Replace with your HC-05 device address
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            // Bluetooth adapter is null or not enabled, show appropriate error message
            Toast.makeText(getActivity(), "Bluetooth is not available or not enabled", Toast.LENGTH_SHORT).show();
            return;
        }

        bluetoothDevice = bluetoothAdapter.getRemoteDevice(deviceAddress);

        try {
            bluetoothSocket = bluetoothDevice.createRfcommSocketToServiceRecord(MY_UUID);
            bluetoothSocket.connect();
            Toast.makeText(getActivity(), "Connected to the device", Toast.LENGTH_SHORT).show();
            outputStream = bluetoothSocket.getOutputStream(); // Initialize output stream
            ConnectedThread connectedThread = new ConnectedThread(bluetoothSocket);
            connectedThread.start();
        } catch (IOException e) {
            Log.e(TAG, "Error connecting to the device", e);
            Toast.makeText(getActivity(), "Error connecting to the device", Toast.LENGTH_SHORT).show();
            // Close the socket if it was opened
            if (bluetoothSocket != null) {
                try {
                    bluetoothSocket.close();
                } catch (IOException ex) {
                    Log.e(TAG, "Error closing Bluetooth socket", ex);
                }
            }
        }
    }

    private void toggleFan() {
        try {
            if (!isFanOn) {
                outputStream.write("1".getBytes()); // Send command to turn on the fan
                isFanOn = true;
                fanButton.setText("Turn Off Fan");
            } else {
                outputStream.write("2".getBytes()); // Send command to turn off the fan
                isFanOn = false;
                fanButton.setText("Turn On Fan");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void togglePump() {
        try {
            if (!isPumpOn) {
                outputStream.write("3".getBytes()); // Send command to turn on the pump
                isPumpOn = true;
                pumpButton.setText("Turn Off Pump");
            } else {
                outputStream.write("4".getBytes()); // Send command to turn off the pump
                isPumpOn = false;
                pumpButton.setText("Turn On Pump");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendCommand(String command) {
        if (bluetoothSocket != null && outputStream != null) {
            try {
                outputStream.write(command.getBytes());
                outputStream.write("\n".getBytes()); // Send a newline character to indicate end of command
            } catch (IOException e) {
                Log.e(TAG, "Error sending command: " + command, e);
                Toast.makeText(getActivity(), "Error sending command", Toast.LENGTH_SHORT).show();
            }
        } else {
            Log.e(TAG, "Bluetooth socket or output stream is null");
            Toast.makeText(getActivity(), "Bluetooth error", Toast.LENGTH_SHORT).show();
        }
    }

    private class ConnectedThread extends Thread {
        private final InputStream inputStream;
        private StringBuilder stringBuilder = new StringBuilder();

        public ConnectedThread(BluetoothSocket socket) {
            InputStream tempIn = null;
            try {
                tempIn = socket.getInputStream();
            } catch (IOException e) {
                Log.e(TAG, "Error occurred when creating input stream", e);
            }
            inputStream = tempIn;
        }

        public void run() {
            byte[] buffer = new byte[1024];
            int bytes;

            while (true) {
                try {
                    bytes = inputStream.read(buffer);
                    if (bytes == -1) {
                        // Handle the case where the input stream returns -1, indicating that the connection is closed
                        Log.e(TAG, "Connection closed unexpectedly");
                        // Attempt to reconnect or notify the user about the connection issue
                        // For example:
                        // connectBluetooth();
                        break;
                    }
                    String readMessage = new String(buffer, 0, bytes);
                    updateReceivedData(readMessage);
                } catch (IOException e) {
                    Log.e(TAG, "Error reading from input stream", e);
                    // Handle the error, such as attempting to reconnect or notifying the user
                    // For example:
                    // connectBluetooth();
                    break;
                }
            }
        }

        private void updateReceivedData(String receivedData) {
            stringBuilder.append(receivedData);
            String data = stringBuilder.toString();
            if (data.contains(";")) {
                String[] packets = data.split(";");
                for (String packet : packets) {
                    parsePacket(packet);
                }
                stringBuilder = new StringBuilder();
            }
        }

        private void parsePacket(String packet) {
            String[] dataParts = packet.split(",");
            if (dataParts.length >= 5) {

                try {
                    double humidity = Double.parseDouble(dataParts[0]);
                    double temperatureCelsius = extractTemperature(dataParts[1]);
                    double temperatureFahrenheit = celsiusToFahrenheit(temperatureCelsius);
                    int moistureLevel = Integer.parseInt(dataParts[2]);
                    String fanStatus = dataParts[3];
                    String pumpStatus = dataParts[4];

                    getActivity().runOnUiThread(() -> {
                        humidityTextView.setText("Humidity: " + humidity);
                        temperatureCelsiusTextView.setText("Temperature (C): " + temperatureCelsius);
                        // Format temperature to display only one decimal place
                        String formattedTemperatureFahrenheit = String.format("%.1f", temperatureFahrenheit);
                        temperatureFahrenheitTextView.setText("Temperature (F): " + formattedTemperatureFahrenheit);
                        moistureLevelTextView.setText("Moisture Level: " + moistureLevel);
                        fanStatusTextView.setText("Fan Status: " + fanStatus);
                        pumpStatusTextView.setText("Pump Status: " + pumpStatus);
                    });
                } catch (NumberFormatException e) {
                    Log.e(TAG, "Error parsing data: " + packet, e);
                }
            } else {
                Log.e(TAG, "Received data packet does not contain enough elements: " + packet);
            }
        }

        private double extractTemperature(String temperatureData) {
            // Extracting numerical value of temperature
            String[] parts = temperatureData.split(" ");
            return Double.parseDouble(parts[0]);
        }

        private double celsiusToFahrenheit(double celsius) {
            // Convert Celsius to Fahrenheit
            return (celsius * 9 / 5) + 32;
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        try {
            if (bluetoothSocket != null) {
                bluetoothSocket.close();
            }
        } catch (IOException e) {
            Log.e(TAG, "Error closing Bluetooth socket", e);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (bluetoothSocket != null && !bluetoothSocket.isConnected()) {
            connectBluetooth();
        }
    }
}